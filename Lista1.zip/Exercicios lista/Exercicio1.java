//Autor: Phillipe W.r Sodre
//R.A:4231925672
//Ciencias da computacao

import java.util.Scanner;
public class Exercicio1 {
    public static void main(String[] args) {
        double numeroUm = 0;
        double numeroDois = 0;
        Scanner scanner = new Scanner(System.in);

        System.out.println("\nInforme o primeiro número: ");
        numeroUm = scanner.nextDouble();

        System.out.println("\nInforme o segundo número: ");
        numeroUm = scanner.nextDouble();

        double mediaAritmetica= (numeroUm + numeroDois)/2;

        System.out.printf("A média aritmética dos numeros é: %.2f", mediaAritmetica);

       scanner.close();
    }
}
