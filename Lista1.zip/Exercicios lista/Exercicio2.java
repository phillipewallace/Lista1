//Autor: Phillipe W.r Sodre
//R.A:4231925672
//Ciencias da computacao
import java.util.Scanner;
public class Exercicio2 {
    public static void main(String[] args) {
  double n1 = 0;
  double n2 = 0;
  double resultado = 0;
  Scanner scanner = new Scanner(System.in);  

System.out.println("Indique o valor da venda: ");
n1 = scanner.nextDouble();

n2 = (n1*10/100);
resultado = (n1+n2);

System.out.printf("O valor final do produto e: %.2f", resultado);

scanner.close();


}
}
