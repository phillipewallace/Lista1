//Autor: Phillipe W.r Sodre
//R.A:4231925672
//Ciencias da computacao
import java.util.Scanner;
public class Exercicio3{
    public static void main(String[] args) {
    double F1 = 0;
    double conversao = 0;   
    Scanner scanner = new Scanner(System.in); 

    System.out.println("Informe o valor da temperatura em Fahrenheit: ");
    F1 = scanner.nextDouble();

    conversao = (F1 - 32)*5/9;

    System.out.printf("O valor da temperatura em Celsius e: %.2f ", conversao);

    scanner.close();


    
}
}