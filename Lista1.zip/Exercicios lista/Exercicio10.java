//Autor: Phillipe W.r Sodre
//R.A:4231925672
//Ciencias da computacao
import java.util.Scanner;
public class Exercicio10 {
    public static void main(String[] args) {
        double A = 0;
        double B = 0;
        double C = 0;
        double mediaArit = 0;
        double mediaHarmo = 0;
        double mediaGeome = 0;
    Scanner scanner = new Scanner(System.in);  

    System.out.println("Escreva o valor de A: ");
    A = scanner.nextDouble();
     System.out.println("Escreva o valor de B: ");
     B = scanner.nextDouble();
      System.out.println ("Escreva o valor de C: ");
     C = scanner.nextDouble();

     mediaArit = (A+B+C)/3;

     mediaHarmo = 3 / (1/A + 1/B + 1/C);

     mediaGeome = (Math.cbrt(A*B*C));

     System.out.printf("A media aritmetica e: " +mediaArit);
     System.out.printf ("\nA media geometrica e: "+mediaGeome);
     System.out.println("\nA media harmonica e: " +mediaHarmo); 

     scanner.close();



}
}
