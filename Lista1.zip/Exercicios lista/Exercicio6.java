//Autor: Phillipe W.r Sodre
//R.A:4231925672
//Ciencias da computacao

import java.util.Scanner; 
public class Exercicio6 {
    public static double log2(int x) {
        
        int B = 0;
        Scanner scanner = new Scanner(System.in);


    System.out.println("Escreva o valor da base: ");
    B = scanner.nextInt();



        return Math.log(x) / Math.log(B);
        
    }
 
    public static void main(String[] args) {
        int x = 0;
        
        Scanner scanner = new Scanner(System.in);

        System.out.println("escreva o valor do numero: ");
        x = scanner.nextInt();

 
        double log2x = log2(x);
        System.out.println(log2x);        

        scanner.close();

    }
}
