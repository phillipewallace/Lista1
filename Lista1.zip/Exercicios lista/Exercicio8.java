//Autor: Phillipe W.r Sodre
//R.A:4231925672
//Ciencias da computacao
import java.util.Scanner;
public class Exercicio8 {
    public static void main(String[] args) {
        int quantidaderodas = 0;
        int quantidadeMotos = 0;
        int quantidadeCarros = 0;
        int quantidadeAutomoveis = 0; 
        int Calculo = 0;
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Escreva o numero total de automoveis estacionados: ");
        quantidadeAutomoveis = scanner.nextInt();

        System.out.println("Escreva o total de rodas:");
        quantidaderodas = scanner.nextInt();

        Calculo = (4*quantidadeAutomoveis) - quantidaderodas/2;
        quantidadeCarros = Calculo/3;
        quantidadeMotos = quantidadeAutomoveis - quantidadeCarros;

        System.out.printf("O numero total de carros e :" + quantidadeCarros + "\nE o numero total de motos e :" + quantidadeMotos);


        scanner.close();
}
}